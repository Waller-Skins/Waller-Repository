# -*- coding: utf-8 -*-
#------------------------------------------------------------
# created by SGK / https://www.facebook.com/groups/kodiunlimited/
#------------------------------------------------------------


import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.Skinbase'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "PLHFZfTOXnuNs0zlhuJ3ztuFmhBScPRrgL"
YOUTUBE_CHANNEL_ID2 = "PLHFZfTOXnuNuJBJGf7_2v-3lCYHctGB0r"
YOUTUBE_CHANNEL_ID3 = "PLHFZfTOXnuNvSrxUxsiC6ft-q3BysLx81"


# Entry point
def run():
    plugintools.log("Skinbase.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("Skinbase.main_list "+repr(params))
   
    plugintools.add_item( 
        title="# [B][COLOR orange]Guidos Skinbase auf YouTube[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.Skinbase/data/icon.png",
        fanart="special://home/addons/plugin.video.Skinbase/fanart.jpg",
        folder=False )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR orange]Skinbase[/COLOR][/B] - Vorschau diverser Kodi-Skins",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail="special://home/addons/plugin.video.Skinbase/data/skin.png",
        fanart="special://home/addons/plugin.video.Skinbase/fanart.jpg",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR orange]Skinbase[/COLOR][/B] Skins bearbeiten - Texturen, Schriften etc.",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",
		thumbnail="special://home/addons/plugin.video.Skinbase/data/textures.png",
        fanart="special://home/addons/plugin.video.Skinbase/fanart.png",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR orange]Skinbase[/COLOR][/B] KODI Tutorials",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail="special://home/addons/plugin.video.Skinbase/data/tutorials.png",
        fanart="special://home/addons/plugin.video.Skinbase/fanart.jpg",
        folder=True )


run()
