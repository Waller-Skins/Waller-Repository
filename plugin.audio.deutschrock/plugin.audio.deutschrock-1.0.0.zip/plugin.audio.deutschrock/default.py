#!/usr/bin/python
# -*- coding: utf-8 -*-
import xbmc, xbmcgui, xbmcaddon, xbmcplugin, os

addon = xbmcaddon.Addon()
addon_path = addon.getAddonInfo('path').decode('utf-8')

name = "[COLOR orange]Deutsch Rock[/COLOR]"
url = "http://crizzfm.stream.laut.fm/crizzfm?t302=2017-11-20_13-25-14&uuid=0b28624f-c84e-468e-8e58-a0e974930207"
iconimage = os.path.join(addon_path,"icon.png")

liz=xbmcgui.ListItem(name, iconImage=iconimage,thumbnailImage=iconimage); liz.setInfo( type="audio", infoLabels={ "Title": name } )
xbmc.Player ().play(url, liz, True)