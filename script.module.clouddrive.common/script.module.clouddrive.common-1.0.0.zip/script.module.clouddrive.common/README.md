# script.module.clouddrive.common


## Usage

```xml
<requires>
    <import addon="script.module.clouddrive.common" version="1.0.0" />
</requires>
```

