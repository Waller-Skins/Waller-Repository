# -*- coding: utf-8 -*-
#------------------------------------------------------------
# copyright by SGK / https://www.facebook.com/groups/kodiunlimited/
#------------------------------------------------------------


import os
import sys
import plugintools
import xbmc,xbmcaddon
from addon.common.addon import Addon

addonID = 'plugin.video.KidsTube'
addon = Addon(addonID, sys.argv)
local = xbmcaddon.Addon(id=addonID)
icon = local.getAddonInfo('icon')
fanart = local.getAddonInfo('fanart')

YOUTUBE_CHANNEL_ID1 = "meinKIKA"
YOUTUBE_CHANNEL_ID2 = "PLizIMM-aNCovzkx9ExqoYxmIzy8mf2pgk"
YOUTUBE_CHANNEL_ID3 = "ZDFtiviKinder"
YOUTUBE_CHANNEL_ID4 = "UCOPJAVJeBhqWL8k7K9Wx6SQ"
YOUTUBE_CHANNEL_ID5 = "Kindernetz"
YOUTUBE_CHANNEL_ID6 = "UCk4sjM2_HAKyCztmtlg31_A"
YOUTUBE_CHANNEL_ID7 = "TOGGOLINOde"
YOUTUBE_CHANNEL_ID8 = "DisneyChannelGermany"
YOUTUBE_CHANNEL_ID9 = "nickelodeonoffiziell"
YOUTUBE_CHANNEL_ID10 = "UCF2IFFQyO5gbhvOCObh1WTQ"
YOUTUBE_CHANNEL_ID11 = "kidstvdeutschland"
YOUTUBE_CHANNEL_ID12 = "UCmZUsl5MLqXIhuSTVP6x-EA"


# Entry point
def run():
    plugintools.log("KidsTube.run")
    
    # Get params
    params = plugintools.get_params()
    
    if params.get("action") is None:
        main_list(params)
    else:
        pass
    
    plugintools.close_item_list()

# Main menu
def main_list(params):
    plugintools.log("KidsTube.main_list "+repr(params))
   
    plugintools.add_item( 
        title="# [B][COLOR red]Kinder-Kanäle & Playlisten auf YouTube[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/KidsTube.png",
        fanart="special://home/addons/plugin.video.KidsTube/fanart.jpg",
        folder=False )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]KIKA[/COLOR][/B] von ARD & ZDF",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID1+"/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kika_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/kika_fanart.png",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]Kikaninchen[/COLOR][/B] von ARD & ZDF",
        url="plugin://plugin.video.youtube/playlist/"+YOUTUBE_CHANNEL_ID2+"/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kikaninchen_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/kikaninchen_fanart.png",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]ZDFtivi[/COLOR][/B] von ZDF",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID3+"/",
		thumbnail="special://home/addons/plugin.video.KidsTube/data/tivi_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/tivi_fanart.png",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]Löwenzahn TV[/COLOR][/B] von ZDF",
        url="plugin://plugin.video.youtube/channel/UCOPJAVJeBhqWL8k7K9Wx6SQ/",
		thumbnail="special://home/addons/plugin.video.Kidstube/data/loewenzahn_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/loewenzahn_fanart.png",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]Kindernetz[/COLOR][/B] von SWR",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID5+"/",
		thumbnail="special://home/addons/plugin.video.KidsTube/data/kindernetz_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/kindernetz_fanart.png",
        folder=True )
   
   
    plugintools.add_item( 
		#action="",
        title="> [B][COLOR yellow]Die Sendung mit der Maus[/COLOR][/B] von WDR",
        url="plugin://plugin.video.youtube/channel/UCk4sjM2_HAKyCztmtlg31_A/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/maus_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/maus_fanart.png",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]Toggolino[/COLOR][/B] von SuperRTL",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID7+"/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/togo_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/togo_fanart.png",
        folder=True )

		
    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]Disney Channel[/COLOR][/B] Deutschland",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID8+"/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/disney_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/disney_fanart.png",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]Nickelodeon[/COLOR][/B] Deutschland",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID9+"/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/nickelodeon_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/nickelodeon_fanart.png",
        folder=True )

		
    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]Kixi[/COLOR][/B] Kinderfilme, Lehrfilme, Lernserien",
        url="plugin://plugin.video.youtube/channel/UCF2IFFQyO5gbhvOCObh1WTQ/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kixi_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/kixi_fanart.png",
        folder=True )


    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR yellow]Kids TV[/COLOR][/B] Deutschland",
        url="plugin://plugin.video.youtube/user/"+YOUTUBE_CHANNEL_ID11+"/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kids_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/kids_fanart.png",
        folder=True )

###################################### Filme ######################################		
     
    plugintools.add_item( 
        title="# [B][COLOR red]Kinderfilme auf YouTube[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kidstube.png",
        fanart="special://home/addons/plugin.video.KidsTube/fanart.jpg",
        folder=False )

		
    plugintools.add_item( 
        #action="", 
        title="> [B][COLOR orange]Kinderkino[/COLOR][/B] von Netzkino",
        url="plugin://plugin.video.youtube/channel/UCmZUsl5MLqXIhuSTVP6x-EA/",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kinderkino_icon.png",
        fanart="special://home/addons/plugin.video.KidsTube/data/kinderkino_fanart.png",
        folder=True )


    plugintools.add_item( 
        title="> [B][COLOR orange]Weitere Kanäle, PLaylisten[/COLOR][/B] [COLOR red]in Bearbeitung...[/COLOR]",
        url="",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kidstube.png",
        fanart="special://home/addons/plugin.video.KidsTube/fanart.jpg",
        folder=False )

###################################### Serien ######################################		
		
    plugintools.add_item( 
        title="# [B][COLOR red]Kinderserien auf YouTube[/COLOR][/B]",
        url="",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kidstube.png",
        fanart="special://home/addons/plugin.video.KidsTube/fanart.jpg",
        folder=False )
		
		
    plugintools.add_item( 
        title="> [B][COLOR lime]Weitere Kanäle, PLaylisten[/COLOR][/B] [COLOR red]in Bearbeitung...[/COLOR]",
        url="",
        thumbnail="special://home/addons/plugin.video.KidsTube/data/kidstube.png",
        fanart="special://home/addons/plugin.video.KidsTube/fanart.jpg",
        folder=False )






run()
